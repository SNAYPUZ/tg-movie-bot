# Telegram Movie Bot
Minimal ZIP loyiha.